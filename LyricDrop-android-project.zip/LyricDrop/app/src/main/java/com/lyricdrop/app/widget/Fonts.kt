package com.lyricdrop.app.widget

import android.content.Context
import android.graphics.Typeface
import com.lyricdrop.app.data.LyricFont

/** Typeface loader for Canvas drawing (widgets + share cards), backed by bundled variable fonts. */
object Fonts {
    private val cache = HashMap<String, Typeface>()

    private fun load(context: Context, asset: String, weight: Int, fallback: Typeface): Typeface {
        val key = "$asset@$weight"
        synchronized(cache) {
            cache[key]?.let { return it }
            val tf = runCatching {
                Typeface.Builder(context.applicationContext.assets, "fonts/$asset")
                    .setFontVariationSettings("'wght' $weight")
                    .build()
            }.getOrNull() ?: fallback
            cache[key] = tf
            return tf
        }
    }

    fun lyric(context: Context, font: LyricFont, weight: Int): Typeface = when (font) {
        LyricFont.SANS -> load(context, "PlusJakartaSans.ttf", weight, Typeface.create("sans-serif", Typeface.BOLD))
        LyricFont.SERIF -> load(context, "PlayfairDisplay.ttf", weight.coerceIn(400, 900), Typeface.SERIF)
        LyricFont.MONO -> load(context, "SpaceMono-Bold.ttf", 700, Typeface.MONOSPACE)
        LyricFont.GROTESK -> load(context, "SpaceGrotesk.ttf", weight.coerceIn(300, 700), Typeface.SANS_SERIF)
    }

    /** UI sans (titles, artist). */
    fun ui(context: Context, weight: Int): Typeface =
        load(context, "PlusJakartaSans.ttf", weight, Typeface.SANS_SERIF)

    /** Telemetry / timestamps. */
    fun tech(context: Context, weight: Int = 500): Typeface =
        load(context, "SpaceGrotesk.ttf", weight.coerceIn(300, 700), Typeface.MONOSPACE)
}
