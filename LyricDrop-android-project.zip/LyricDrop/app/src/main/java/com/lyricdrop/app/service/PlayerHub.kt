package com.lyricdrop.app.service

import android.media.session.MediaController
import com.lyricdrop.app.data.LyricsState
import com.lyricdrop.app.data.NowPlaying
import kotlinx.coroutines.flow.MutableStateFlow

/** Shared in-process state written by [NowPlayingService] and read by the UI and widgets. */
object PlayerHub {
    val nowPlaying = MutableStateFlow<NowPlaying?>(null)
    val lyrics = MutableStateFlow<LyricsState>(LyricsState.Idle)
    val listenerConnected = MutableStateFlow(false)

    /** Bumped from Activity.onResume so the UI can re-check permissions. */
    val resumeTick = MutableStateFlow(0)

    @Volatile
    var controller: MediaController? = null

    fun playPause() {
        val c = controller ?: return
        if (nowPlaying.value?.isPlaying == true) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() { controller?.transportControls?.skipToNext() }
    fun previous() { controller?.transportControls?.skipToPrevious() }
    fun seekTo(ms: Long) { controller?.transportControls?.seekTo(ms) }
}
