package com.lyricdrop.app.service

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import com.lyricdrop.app.data.LrcParser
import com.lyricdrop.app.data.LyricsRepository
import com.lyricdrop.app.data.LyricsState
import com.lyricdrop.app.data.NowPlaying
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.widget.WidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Notification-listener service. Holding notification access is what lets us enumerate other apps'
 * media sessions. We attach to Spotify's session, mirror it into [PlayerHub], fetch lyrics for each
 * new track, and keep home-screen widgets in sync.
 */
class NowPlayingService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var sessionManager: MediaSessionManager? = null
    private var listenerComponent: ComponentName? = null
    private var controller: MediaController? = null
    private var lyricsJob: Job? = null
    private var tickJob: Job? = null
    private var lastKey: String? = null
    private var lastSig: String = ""

    private var srcArt: Bitmap? = null
    private var scaledArt: Bitmap? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list.orEmpty()) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onSessionDestroyed() = detach()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        PlayerHub.listenerConnected.value = true
        val msm = getSystemService(MediaSessionManager::class.java)
        sessionManager = msm
        val cn = ComponentName(this, NowPlayingService::class.java)
        listenerComponent = cn
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            attach(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {
            PlayerHub.listenerConnected.value = false
        }
        startTicker()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        PlayerHub.listenerConnected.value = false
        runCatching { sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener) }
        detach()
        tickJob?.cancel()
    }

    override fun onDestroy() {
        runCatching { sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener) }
        controller?.unregisterCallback(callback)
        PlayerHub.controller = null
        PlayerHub.listenerConnected.value = false
        scope.cancel()
        super.onDestroy()
    }

    private fun attach(sessions: List<MediaController>) {
        val target = sessions.firstOrNull { it.packageName in SPOTIFY_PACKAGES }
        if (target?.sessionToken == controller?.sessionToken && controller != null) {
            publish(); return
        }
        controller?.unregisterCallback(callback)
        controller = target
        PlayerHub.controller = target
        target?.registerCallback(callback)
        publish()
    }

    private fun detach() {
        controller?.unregisterCallback(callback)
        controller = null
        PlayerHub.controller = null
        PlayerHub.nowPlaying.value = null
        PlayerHub.lyrics.value = LyricsState.Idle
        lastKey = null
        pushWidgets(force = true)
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            PlayerHub.nowPlaying.value = null
            return
        }
        val md = c.metadata
        val st = c.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = (md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty()
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty()
        val duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        // Skip ads and empty metadata.
        val isAd = title.equals("Advertisement", true) || title.equals("Spotify", true) || artist.isBlank()
        if (md == null || title.isBlank() || isAd) {
            PlayerHub.nowPlaying.value = null
            PlayerHub.lyrics.value = LyricsState.Idle
            lastKey = null
            return
        }

        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        val np = NowPlaying(
            title = title,
            artist = artist,
            album = album,
            durationMs = duration,
            isPlaying = st?.state == PlaybackState.STATE_PLAYING || st?.state == PlaybackState.STATE_BUFFERING,
            positionMs = st?.position?.takeIf { it >= 0 } ?: 0L,
            positionUpdateTime = st?.lastPositionUpdateTime ?: android.os.SystemClock.elapsedRealtime(),
            speed = st?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
            art = scaleArt(art),
        )
        PlayerHub.nowPlaying.value = np

        if (np.key != lastKey) {
            lastKey = np.key
            lyricsJob?.cancel()
            PlayerHub.lyrics.value = LyricsState.Loading
            val appCtx = applicationContext
            lyricsJob = scope.launch {
                PlayerHub.lyrics.value = LyricsRepository.fetch(appCtx, np)
            }
        }
    }

    private fun scaleArt(src: Bitmap?): Bitmap? {
        if (src == null) return null
        if (src === srcArt) return scaledArt
        srcArt = src
        scaledArt = runCatching {
            val max = 360
            val scale = max.toFloat() / maxOf(src.width, src.height)
            if (scale >= 1f) src.copy(Bitmap.Config.ARGB_8888, false)
            else Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        }.getOrNull()
        return scaledArt
    }

    /** Pushes the current lyric line to widgets whenever the visible content changes. */
    private fun startTicker() {
        tickJob?.cancel()
        tickJob = scope.launch {
            while (true) {
                pushWidgets(force = false)
                delay(400)
            }
        }
    }

    private suspend fun pushWidgetsSuspend() {
        withContext(Dispatchers.Default) { WidgetUpdater.updateAll(applicationContext) }
    }

    private fun pushWidgets(force: Boolean) {
        val np = PlayerHub.nowPlaying.value
        val lyrics = PlayerHub.lyrics.value
        val settings = SettingsStore.state.value
        val idx = (lyrics as? LyricsState.Synced)?.let {
            LrcParser.indexAt(it.lines, (np?.positionNow() ?: 0L) + settings.offsetMs)
        } ?: -1
        val progressBucket = (np?.positionNow() ?: 0L) / 5000
        val sig = "${np?.key}|${np?.isPlaying}|${lyrics::class.simpleName}|$idx|$progressBucket|${settings.hashCode()}"
        if (!force && sig == lastSig) return
        lastSig = sig
        scope.launch { pushWidgetsSuspend() }
    }

    companion object {
        val SPOTIFY_PACKAGES = setOf("com.spotify.music", "com.spotify.lite")
    }
}
