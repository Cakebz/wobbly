@file:OptIn(ExperimentalTextApi::class)

package com.lyricdrop.app.ui

import android.content.Context
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight

/** Design tokens from the Stitch "Syncline" design system. */
object Pal {
    val Bg = Color(0xFF0A0B0E)
    val Surface = Color(0xFF121316)
    val Card = Color(0xFF1B1B1F)
    val CardHigh = Color(0xFF25262A)
    val Green = Color(0xFF1DB954)
    val GreenBright = Color(0xFF53E076)
    val OnGreen = Color(0xFF003914)
    val Purple = Color(0xFF9D4EDD)
    val PurpleSoft = Color(0xFFE0B6FF)
    val Magenta = Color(0xFFFF3366)
    val Text = Color(0xFFFFFFFF)
    val TextSec = Color(0x94FFFFFF)   // 58%
    val TextTer = Color(0x52FFFFFF)   // 32%
    val Hairline = Color(0x14FFFFFF)  // 8%
}

class AppFonts(
    val sans: FontFamily,
    val tech: FontFamily,
    val serif: FontFamily,
    val mono: FontFamily,
)

private fun variableFamily(ctx: Context, file: String, weights: List<Int>): FontFamily {
    val present = runCatching { ctx.assets.list("fonts")?.contains(file) == true }.getOrDefault(false)
    if (!present) return FontFamily.Default
    return FontFamily(
        weights.map { w ->
            Font(file, ctx.assets, FontWeight(w), FontStyle.Normal, FontVariation.Settings(FontVariation.weight(w)))
        },
    )
}

private fun staticFamily(ctx: Context, file: String, weight: FontWeight, fallback: FontFamily): FontFamily {
    val present = runCatching { ctx.assets.list("fonts")?.contains(file) == true }.getOrDefault(false)
    return if (present) FontFamily(Font(file, ctx.assets, weight)) else fallback
}

fun buildFonts(ctx: Context) = AppFonts(
    sans = variableFamily(ctx, "PlusJakartaSans.ttf", listOf(400, 500, 600, 700, 800)),
    tech = variableFamily(ctx, "SpaceGrotesk.ttf", listOf(400, 500, 600, 700)),
    serif = variableFamily(ctx, "PlayfairDisplay.ttf", listOf(400, 600, 800)),
    mono = staticFamily(ctx, "SpaceMono-Bold.ttf", FontWeight.Bold, FontFamily.Monospace),
)

val LocalFonts = staticCompositionLocalOf<AppFonts> { error("Fonts not provided") }

private fun typography(sans: FontFamily): Typography {
    val d = Typography()
    fun TextStyle.f() = copy(fontFamily = sans)
    return Typography(
        displayLarge = d.displayLarge.f(), displayMedium = d.displayMedium.f(), displaySmall = d.displaySmall.f(),
        headlineLarge = d.headlineLarge.f(), headlineMedium = d.headlineMedium.f(), headlineSmall = d.headlineSmall.f(),
        titleLarge = d.titleLarge.f(), titleMedium = d.titleMedium.f(), titleSmall = d.titleSmall.f(),
        bodyLarge = d.bodyLarge.f(), bodyMedium = d.bodyMedium.f(), bodySmall = d.bodySmall.f(),
        labelLarge = d.labelLarge.f(), labelMedium = d.labelMedium.f(), labelSmall = d.labelSmall.f(),
    )
}

@Composable
fun LyricDropTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val fonts = remember { buildFonts(ctx) }
    val scheme = darkColorScheme(
        primary = Pal.Green,
        onPrimary = Pal.OnGreen,
        secondary = Pal.Purple,
        background = Pal.Bg,
        surface = Pal.Surface,
        onSurface = Color(0xFFE3E2E6),
        onBackground = Color(0xFFE3E2E6),
        surfaceVariant = Pal.CardHigh,
    )
    CompositionLocalProvider(LocalFonts provides fonts) {
        MaterialTheme(colorScheme = scheme, typography = typography(fonts.sans), content = content)
    }
}
