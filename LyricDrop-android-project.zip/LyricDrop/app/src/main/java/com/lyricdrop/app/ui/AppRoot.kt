package com.lyricdrop.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import com.lyricdrop.app.data.WidgetKind

private data class TabSpec(val label: String, val icon: ImageVector)

@Composable
fun AppRoot() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var kindName by rememberSaveable { mutableStateOf(WidgetKind.MEDIUM.name) }
    var savedMode by rememberSaveable { mutableIntStateOf(0) }
    var selectedSnippet by rememberSaveable { mutableLongStateOf(-1L) }
    val kind = WidgetKind.valueOf(kindName)

    val tabs = listOf(
        TabSpec("Now Playing", Icons.Rounded.MusicNote),
        TabSpec("Widgets", Icons.Rounded.Widgets),
        TabSpec("Studio", Icons.Rounded.Tune),
        TabSpec("Saved", Icons.Rounded.Bookmarks),
    )

    Scaffold(
        containerColor = Pal.Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0F1013)) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Pal.GreenBright, selectedTextColor = Pal.GreenBright,
                            unselectedIconColor = Pal.TextSec, unselectedTextColor = Pal.TextSec,
                            indicatorColor = Color(0x1F1DB954),
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> NowPlayingScreen(onOpenWidgets = { tab = 1 })
                1 -> WidgetsScreen(onCustomize = { kindName = it.name; tab = 2 })
                2 -> StudioScreen(kind, onKindChange = { kindName = it.name })
                else -> SavedScreen(savedMode, { savedMode = it }, selectedSnippet, { selectedSnippet = it })
            }
        }
    }
}
