package com.lyricdrop.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeStyle(val label: String, val sub: String) {
    FROSTED("Frosted Glass", "Translucent aero depth"),
    AMOLED("Pure AMOLED", "Deep pitch obsidian"),
    ALBUM("Dynamic Album", "Artwork responsive"),
    VINYL("Vintage Vinyl", "Analog warmth"),
    NEON("Cyber Neon", "High-octane synths"),
}

enum class LyricFont(val label: String, val preview: String) {
    SANS("Modern Sans", "Style 01"),
    SERIF("Editorial Serif", "Style 02"),
    MONO("Cyber Mono", "Style 03"),
    GROTESK("Bold Grotesk", "Style 04"),
}

enum class GlowColor(val label: String, val argb: Int) {
    GREEN("Green", 0xFF1DB954.toInt()),
    LILAC("Lilac", 0xFFD8B4FE.toInt()),
    CYAN("Cyan", 0xFF5EEAD4.toInt()),
    AMBER("Amber", 0xFFFFB74D.toInt()),
}

enum class WidgetKind(val title: String, val badge: String, val subtitle: String) {
    COMPACT("Compact 2×2 Glaze", "Square", "Current line at a glance"),
    MEDIUM("Medium 4×2 Karaoke Scroller", "Most Popular", "Three-line lookahead with progress"),
    PILL("Slim 4×1 Pill", "Minimal", "One-line lyric ticker"),
    LARGE("Large 4×4 Editorial Poster", "Poster", "Album art with a big pull-quote"),
}

data class WidgetSettings(
    val theme: ThemeStyle = ThemeStyle.FROSTED,
    val opacity: Float = 0.85f,
    val font: LyricFont = LyricFont.SANS,
    val glow: GlowColor = GlowColor.GREEN,
    val showArt: Boolean = true,
    val showProgress: Boolean = true,
    val contextLines: Int = 3,
    /** Manual sync offset applied to lyric timestamps (positive = lyrics appear earlier). */
    val offsetMs: Long = 0L,
)

object SettingsStore {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(WidgetSettings())
    val state: StateFlow<WidgetSettings> = _state.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        _state.value = WidgetSettings(
            theme = enumOf(prefs.getString("theme", null), ThemeStyle.FROSTED),
            opacity = prefs.getFloat("opacity", 0.85f),
            font = enumOf(prefs.getString("font", null), LyricFont.SANS),
            glow = enumOf(prefs.getString("glow", null), GlowColor.GREEN),
            showArt = prefs.getBoolean("showArt", true),
            showProgress = prefs.getBoolean("showProgress", true),
            contextLines = prefs.getInt("contextLines", 3),
            offsetMs = prefs.getLong("offsetMs", 0L),
        )
    }

    fun update(block: (WidgetSettings) -> WidgetSettings) {
        val s = block(_state.value)
        _state.value = s
        prefs.edit()
            .putString("theme", s.theme.name)
            .putFloat("opacity", s.opacity)
            .putString("font", s.font.name)
            .putString("glow", s.glow.name)
            .putBoolean("showArt", s.showArt)
            .putBoolean("showProgress", s.showProgress)
            .putInt("contextLines", s.contextLines)
            .putLong("offsetMs", s.offsetMs)
            .apply()
    }

    private inline fun <reified T : Enum<T>> enumOf(name: String?, default: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: default
}
