package com.lyricdrop.app

import android.app.Application
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.SnippetStore

class LyricDropApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        SnippetStore.init(this)
    }
}
