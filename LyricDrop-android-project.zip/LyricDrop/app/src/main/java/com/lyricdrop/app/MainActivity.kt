package com.lyricdrop.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.ui.AppRoot
import com.lyricdrop.app.ui.LyricDropTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent { LyricDropTheme { AppRoot() } }
    }

    override fun onResume() {
        super.onResume()
        // Lets the UI re-check notification access after returning from system settings.
        PlayerHub.resumeTick.value = PlayerHub.resumeTick.value + 1
    }
}
