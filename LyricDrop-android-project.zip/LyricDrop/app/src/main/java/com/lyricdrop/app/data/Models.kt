package com.lyricdrop.app.data

import android.graphics.Bitmap
import android.os.SystemClock

/** Snapshot of what Spotify is playing, taken from its Android media session. */
data class NowPlaying(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val isPlaying: Boolean,
    val positionMs: Long,
    /** SystemClock.elapsedRealtime() at the moment positionMs was reported. */
    val positionUpdateTime: Long,
    val speed: Float,
    val art: Bitmap?,
) {
    val key: String get() = "$title|$artist|${durationMs / 1000}"

    /** Interpolated playback position, right now. */
    fun positionNow(): Long {
        if (!isPlaying) return positionMs.coerceAtLeast(0)
        val elapsed = SystemClock.elapsedRealtime() - positionUpdateTime
        val p = positionMs + (elapsed * speed).toLong()
        return if (durationMs > 0) p.coerceIn(0, durationMs) else p.coerceAtLeast(0)
    }
}

data class LrcLine(val timeMs: Long, val text: String)

sealed interface LyricsState {
    data object Idle : LyricsState
    data object Loading : LyricsState
    data class Synced(val lines: List<LrcLine>) : LyricsState
    data class Plain(val text: String) : LyricsState
    data object Instrumental : LyricsState
    data object NotFound : LyricsState
    data class Error(val message: String) : LyricsState
}

data class Snippet(
    val id: Long,
    val title: String,
    val artist: String,
    val text: String,
    val timeMs: Long,
    val createdAt: Long,
    val liked: Boolean = false,
)

fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0) / 1000)
    return "%02d:%02d".format(total / 60, total % 60)
}
