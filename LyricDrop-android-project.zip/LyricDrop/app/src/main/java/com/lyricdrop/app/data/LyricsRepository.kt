package com.lyricdrop.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.math.abs

/**
 * Fetches time-synced lyrics from LRCLIB (https://lrclib.net) - a free, open lyrics database.
 * Results are cached on disk so each song is only fetched once.
 */
object LyricsRepository {
    private const val BASE = "https://lrclib.net/api"
    private const val UA = "LyricDrop/1.0 (Android lyrics widget)"
    private val memory = HashMap<String, LyricsState>()

    private val suffixDash = Regex(
        """\s+[-–—]\s+(\d{4}\s+)?(remaster(ed)?|live|radio edit|mono|stereo|single version|album version|bonus track|deluxe|acoustic|version|edit|from\b).*$""",
        RegexOption.IGNORE_CASE,
    )
    private val suffixParen = Regex(
        """\s*[(\[]\s*(feat|ft|with|remaster|live|deluxe|bonus|mono|stereo|radio|version)[^)\]]*[)\]]""",
        RegexOption.IGNORE_CASE,
    )

    fun cleanTitle(title: String): String =
        title.replace(suffixDash, "").replace(suffixParen, "").trim().ifBlank { title }

    suspend fun fetch(context: Context, np: NowPlaying): LyricsState = withContext(Dispatchers.IO) {
        val key = np.key
        synchronized(memory) { memory[key] }?.let { return@withContext it }

        val file = File(File(context.cacheDir, "lyrics").apply { mkdirs() }, md5(key) + ".json")
        if (file.exists()) {
            runCatching { fromJson(JSONObject(file.readText())) }.getOrNull()?.let {
                synchronized(memory) { memory[key] = it }
                return@withContext it
            }
        }

        try {
            val json = lookup(np)
            val state = if (json == null) LyricsState.NotFound else fromJson(json)
            // Cache hits and definitive misses; don't cache transient errors.
            synchronized(memory) { memory[key] = state }
            if (json != null) runCatching { file.writeText(json.toString()) }
            state
        } catch (e: Exception) {
            LyricsState.Error(e.message ?: "Network error")
        }
    }

    private fun fromJson(j: JSONObject): LyricsState {
        if (j.optBoolean("instrumental", false)) return LyricsState.Instrumental
        val synced = j.optString("syncedLyrics", "")
        if (synced.isNotBlank() && synced != "null") {
            val lines = LrcParser.parse(synced)
            if (lines.isNotEmpty()) return LyricsState.Synced(lines)
        }
        val plain = j.optString("plainLyrics", "")
        if (plain.isNotBlank() && plain != "null") return LyricsState.Plain(plain)
        return LyricsState.NotFound
    }

    private fun lookup(np: NowPlaying): JSONObject? {
        val titles = listOf(np.title, cleanTitle(np.title)).distinct()
        val durSec = (np.durationMs / 1000).toInt()
        // 1) exact signature match
        for (t in titles) {
            val q = "track_name=${enc(t)}&artist_name=${enc(np.artist)}&album_name=${enc(np.album)}&duration=$durSec"
            get("$BASE/get?$q")?.let { return it as? JSONObject }
        }
        // 2) without album
        for (t in titles) {
            val q = "track_name=${enc(t)}&artist_name=${enc(np.artist)}" + if (durSec > 0) "&duration=$durSec" else ""
            get("$BASE/get?$q")?.let { return it as? JSONObject }
        }
        // 3) search, prefer synced results with the closest duration
        for (t in titles) {
            val arr = get("$BASE/search?track_name=${enc(t)}&artist_name=${enc(np.artist)}") as? JSONArray ?: continue
            var best: JSONObject? = null
            var bestScore = Long.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val hasSynced = o.optString("syncedLyrics", "").let { it.isNotBlank() && it != "null" }
                val diff = abs(o.optDouble("duration", 0.0) - durSec).toLong()
                val score = diff + if (hasSynced) 0 else 1000
                if (score < bestScore) { bestScore = score; best = o }
            }
            if (best != null) return best
        }
        return null
    }

    /** Returns JSONObject / JSONArray, or null on 404. Throws on other failures. */
    private fun get(url: String): Any? {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/json")
            val code = conn.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw java.io.IOException("LRCLIB returned HTTP $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            return if (body.startsWith("[")) JSONArray(body) else JSONObject(body)
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String) = Uri.encode(s)

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
