package com.lyricdrop.app.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.lyricdrop.app.data.LrcParser
import com.lyricdrop.app.data.LyricsState
import com.lyricdrop.app.data.NowPlaying
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.SnippetStore
import com.lyricdrop.app.data.formatTime
import com.lyricdrop.app.service.NowPlayingService
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.widget.WidgetUpdater
import kotlin.math.abs
import kotlin.math.max

fun hasListenerAccess(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(send, "Share lyric").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun offsetLabel(ms: Long): String {
    val sign = if (ms >= 0) "+" else "-"
    return "SYNC $sign%.1fs".format(abs(ms) / 1000f)
}

@Composable
fun NowPlayingScreen(onOpenWidgets: () -> Unit) {
    val ctx = LocalContext.current
    val np by PlayerHub.nowPlaying.collectAsState()
    val lyrics by PlayerHub.lyrics.collectAsState()
    val connected by PlayerHub.listenerConnected.collectAsState()
    val resume by PlayerHub.resumeTick.collectAsState()
    val settings by SettingsStore.state.collectAsState()
    @Suppress("UNUSED_VARIABLE") val tick by rememberTicker(250)

    val access = remember(resume, connected) { hasListenerAccess(ctx) }
    var follow by remember { mutableStateOf(true) }

    LaunchedEffect(resume, access, connected) {
        if (access && !connected) {
            runCatching { NotificationListenerService.requestRebind(ComponentName(ctx, NowPlayingService::class.java)) }
        }
    }

    val status = when {
        np != null -> "Spotify Connected • ${np!!.artist}"
        connected -> "Listening for Spotify…"
        access -> "Starting listener…"
        else -> "Notification access needed"
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(status, ok = np != null)
        if (!access) {
            AccessCard(ctx)
            return@Column
        }
        PlayerCard(np, settings.offsetMs)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LyricsPane(np, lyrics, settings.offsetMs, follow, { follow = it }, onOpenWidgets)
            if (np != null) SideTools(np!!, lyrics, settings.offsetMs, { follow = true }, Modifier.align(Alignment.CenterEnd))
        }
    }
}

@Composable
private fun AccessCard(ctx: Context) {
    GlassCard(Modifier.fillMaxWidth().padding(20.dp), radius = 20.dp) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("One quick permission", color = Pal.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "LyricDrop needs Notification access so Android lets it see what Spotify is playing " +
                    "(song, artist and playback position). It never reads your notifications' contents.",
                color = Pal.TextSec, fontSize = 14.sp, lineHeight = 21.sp,
            )
            Text(
                "Tap the button, switch on LyricDrop, then come back. If Android blocks it, open " +
                    "App info → ⋮ → \"Allow restricted settings\" first.",
                color = Pal.TextTer, fontSize = 12.sp, lineHeight = 18.sp,
            )
            Box(
                Modifier.fillMaxWidth().clip(CircleShape).background(Pal.Green)
                    .clickable { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Grant notification access", color = Pal.OnGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
        }
    }
}

@Composable
private fun PlayerCard(np: NowPlaying?, offsetMs: Long) {
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), radius = 22.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(np?.art, 56.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(
                        np?.title ?: "Nothing playing", color = Pal.Text, fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        if (np != null) "${np.artist}${if (np.album.isNotBlank()) " • ${np.album}" else ""}"
                        else "Open Spotify and press play",
                        color = Pal.TextSec, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Chip(offsetLabel(offsetMs))
            }
            val pos = np?.positionNow() ?: 0L
            val dur = np?.durationMs ?: 0L
            Column(
                Modifier.padding(top = 12.dp).pointerInput(np?.key) {
                    detectTapGestures { o: Offset ->
                        if (dur > 0) PlayerHub.seekTo((o.x / size.width * dur).toLong())
                    }
                },
            ) {
                GradientProgress(if (dur > 0) pos.toFloat() / dur else 0f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TechText(formatTime(pos), Pal.GreenBright)
                    TechText(formatTime(dur))
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundIcon(Icons.Rounded.SkipPrevious, "Previous") { PlayerHub.previous() }
                Row(
                    Modifier.clip(CircleShape).background(Pal.GreenBright)
                        .clickable { PlayerHub.playPause() }
                        .padding(horizontal = 36.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(if (np?.isPlaying == true) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Pal.OnGreen)
                    Text(
                        if (np?.isPlaying == true) "PLAYING" else "PAUSED",
                        color = Pal.OnGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, letterSpacing = 1.sp,
                    )
                }
                RoundIcon(Icons.Rounded.SkipNext, "Next") { PlayerHub.next() }
            }
        }
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, tint: Color = Color.White, bg: Color = Color.Transparent, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint) }
}

@Composable
private fun LyricsPane(
    np: NowPlaying?, lyrics: LyricsState, offsetMs: Long,
    follow: Boolean, onFollowChange: (Boolean) -> Unit, onOpenWidgets: () -> Unit,
) {
    val ctx = LocalContext.current
    val listState = rememberLazyListState()
    val fonts = LocalFonts.current

    val synced = lyrics as? LyricsState.Synced
    val pos = np?.positionNow() ?: 0L
    val idx = if (synced != null) LrcParser.indexAt(synced.lines, pos + offsetMs) else -1

    var programmatic by remember { mutableStateOf(false) }
    LaunchedEffect(idx, follow, np?.key) {
        if (follow && idx >= 0) {
            programmatic = true
            try { listState.animateScrollToItem(max(0, idx - 1)) } finally { programmatic = false }
        }
    }
    LaunchedEffect(listState.isScrollInProgress) {
        if (listState.isScrollInProgress && !programmatic) onFollowChange(false)
    }
    LaunchedEffect(np?.key) { onFollowChange(true) }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(start = 20.dp, end = 64.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        when {
            np == null -> item { Hint("Play something on Spotify and its lyrics will scroll here in real time.") }
            lyrics is LyricsState.Loading -> item { Hint("Fetching lyrics…") }
            lyrics is LyricsState.NotFound -> item { Hint("No lyrics found for this track.") }
            lyrics is LyricsState.Instrumental -> item { Hint("♪ Instrumental ♪") }
            lyrics is LyricsState.Error -> item { Hint("Couldn't reach the lyrics service. Check your connection.") }
            lyrics is LyricsState.Plain -> {
                item { Chip("NOT TIME-SYNCED", Pal.PurpleSoft) }
                item { Text(lyrics.text, color = Pal.TextSec, fontSize = 18.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold) }
            }
            synced != null -> {
                itemsIndexed(synced.lines) { i, line ->
                    val active = i == idx
                    val text = line.text.ifBlank { "♪" }
                    if (active) {
                        GlassCard(
                            Modifier.fillMaxWidth(), radius = 20.dp,
                            background = Color(0xFF17201A), borderColor = Pal.Green.copy(alpha = 0.35f),
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Chip("NOW VOCALIZING", Pal.GreenBright, Pal.Green.copy(alpha = 0.15f))
                                    Chip(formatTime(line.timeMs), Pal.TextSec)
                                }
                                Text(
                                    text,
                                    style = TextStyle(
                                        fontFamily = fonts.sans, fontWeight = FontWeight.ExtraBold,
                                        fontSize = 28.sp, lineHeight = 36.sp, letterSpacing = (-0.7).sp,
                                        color = Pal.GreenBright,
                                        shadow = Shadow(Pal.Green.copy(alpha = 0.45f), Offset.Zero, 24f),
                                    ),
                                    modifier = Modifier.clickable { PlayerHub.seekTo(line.timeMs) },
                                )
                            }
                        }
                    } else {
                        Column(Modifier.clickable { PlayerHub.seekTo(line.timeMs) }) {
                            TechText(formatTime(line.timeMs), Pal.TextTer)
                            Text(
                                text, color = Color.White.copy(alpha = if (abs(i - idx) <= 2) 0.5f else 0.3f),
                                fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp,
                            )
                        }
                    }
                }
            }
        }

        item {
            val current = if (synced != null && idx >= 0) synced.lines[idx].text else ""
            if (np != null && current.isNotBlank()) {
                GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp), radius = 20.dp) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Rounded.AutoAwesome, null, tint = Pal.PurpleSoft, modifier = Modifier.size(16.dp))
                                Text("READY TO SHARE", color = Pal.PurpleSoft, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                            }
                            Text(
                                "“$current”", color = Pal.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp),
                            )
                            Text("${np.artist} • ${np.title}", color = Pal.TextTer, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Box(
                            Modifier.padding(start = 10.dp).clip(CircleShape).background(Color(0xFF6D11AD))
                                .clickable { shareText(ctx, "“$current”\n— ${np.artist}, ${np.title}") }
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                        ) { Text("Drop", color = Color(0xFFF2DAFF), fontWeight = FontWeight.ExtraBold) }
                    }
                }
            }
        }
        item {
            val count = WidgetUpdater.activeCount(ctx)
            GlassCard(Modifier.fillMaxWidth().clickable(onClick = onOpenWidgets), radius = 16.dp) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Widgets, null, tint = Pal.GreenBright)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("Home-screen widgets", color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            if (count == 0) "None added yet — tap to add one" else "$count active — tap to manage",
                            color = Pal.TextSec, fontSize = 12.sp,
                        )
                    }
                }
            }
        }
        item {
            TechText("Source: Spotify media session • Lyrics: LRCLIB", modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Pal.TextSec, fontSize = 16.sp, lineHeight = 24.sp, modifier = Modifier.padding(top = 24.dp))
}

@Composable
private fun SideTools(np: NowPlaying, lyrics: LyricsState, offsetMs: Long, onLocate: () -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val synced = lyrics as? LyricsState.Synced
    fun currentLine(): String? {
        val s = synced ?: return null
        val i = LrcParser.indexAt(s.lines, np.positionNow() + offsetMs)
        return s.lines.getOrNull(i)?.text?.takeIf { it.isNotBlank() }
    }
    Column(
        modifier.padding(end = 8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xE61F1F23)).padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        RoundIcon(Icons.Rounded.BookmarkAdd, "Save lyric", Pal.GreenBright, Pal.CardHigh) {
            val line = currentLine()
            if (line != null) {
                SnippetStore.add(np.title, np.artist, line, np.positionNow())
                Toast.makeText(ctx, "Saved to Snippets", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(ctx, "No synced line to save yet", Toast.LENGTH_SHORT).show()
        }
        RoundIcon(Icons.Rounded.Share, "Share lyric", Color.White, Pal.CardHigh) {
            currentLine()?.let { shareText(ctx, "“$it”\n— ${np.artist}, ${np.title}") }
        }
        RoundIcon(Icons.Rounded.MyLocation, "Jump to current line", Color.White, Pal.CardHigh) { onLocate() }
        OffsetButton("+0.2") { SettingsStore.update { it.copy(offsetMs = it.offsetMs + 200) } }
        TechText("SEC", Pal.TextTer, 9, Modifier.align(Alignment.CenterHorizontally))
        OffsetButton("-0.2") { SettingsStore.update { it.copy(offsetMs = it.offsetMs - 200) } }
    }
}

@Composable
private fun OffsetButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Pal.CardHigh).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { TechText(label, Color.White, 13) }
}
