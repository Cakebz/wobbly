package com.lyricdrop.app.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.WidgetKind
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.widget.WidgetUpdater

fun pinWidget(ctx: Context, kind: WidgetKind) {
    val mgr = AppWidgetManager.getInstance(ctx)
    if (mgr.isRequestPinAppWidgetSupported) {
        mgr.requestPinAppWidget(ComponentName(ctx, WidgetUpdater.providerFor(kind)), null, null)
    } else {
        Toast.makeText(ctx, "Your launcher can't pin widgets directly. Long-press the home screen → Widgets → LyricDrop.", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun WidgetsScreen(onCustomize: (WidgetKind) -> Unit) {
    val ctx = LocalContext.current
    val settings by SettingsStore.state.collectAsState()
    val np by PlayerHub.nowPlaying.collectAsState()
    val resume by PlayerHub.resumeTick.collectAsState()
    val input = rememberLiveInput()
    val count = remember(resume) { WidgetUpdater.activeCount(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        TopBar(if (np != null) "Spotify Connected • ${np!!.artist}" else "Preview mode", np != null)
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), radius = 20.dp) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Home Screen Widgets", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Chip("$count Active", Pal.GreenBright, Pal.Green.copy(alpha = 0.15f))
                }
                Text(
                    "Real-time lyric sync, drawn live from your Spotify session. Tap “Add to Home”, or long-press your home screen → Widgets → LyricDrop.",
                    color = Pal.TextSec, fontSize = 13.sp, lineHeight = 19.sp,
                )
            }
        }

        WidgetKind.entries.forEach { kind ->
            val (w, h) = WidgetUpdater.defaultSizeDp(kind)
            val preview = rememberWidgetPreview(kind, settings, input, w, h)
            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Pal.GreenBright))
                    Text(kind.title, color = Pal.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                    Chip(kind.badge, Pal.TextSec)
                }
                Box(
                    Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).background(Color(0xFF111215)).padding(14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (preview != null) {
                        Image(
                            preview, contentDescription = kind.title, contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth(if (kind == WidgetKind.COMPACT) 0.55f else 1f).aspectRatio(w / h),
                        )
                    } else Box(Modifier.fillMaxWidth().aspectRatio(w / h))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f).clip(CircleShape).background(Pal.GreenBright).clickable { pinWidget(ctx, kind) }.padding(vertical = 13.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = Pal.OnGreen, modifier = Modifier.size(18.dp))
                        Text("Add to Home", color = Pal.OnGreen, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
                    }
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(Pal.CardHigh).clickable { onCustomize(kind) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Tune, "Customize", tint = Color.White) }
                }
            }
        }
    }
}
