package com.lyricdrop.app.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyricdrop.app.data.GlowColor
import com.lyricdrop.app.data.LyricFont
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.ThemeStyle
import com.lyricdrop.app.data.WidgetKind
import com.lyricdrop.app.data.WidgetSettings
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.widget.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun StudioScreen(kind: WidgetKind, onKindChange: (WidgetKind) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by SettingsStore.state.collectAsState()
    val np by PlayerHub.nowPlaying.collectAsState()
    val input = rememberLiveInput()
    val fonts = LocalFonts.current
    val (w, h) = WidgetUpdater.defaultSizeDp(kind)
    val preview = rememberWidgetPreview(kind, settings, input, w, h)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
        TopBar(if (np != null) "Spotify Connected • ${np!!.artist}" else "Preview mode", np != null)

        // --- live preview ---
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("LIVE PREVIEW", color = Pal.GreenBright, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                Chip(if (np != null) "Live Sync" else "Demo", Pal.GreenBright)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                WidgetKind.entries.forEach { k ->
                    val sel = k == kind
                    Box(
                        Modifier.clip(CircleShape).background(if (sel) Pal.Green else Pal.CardHigh)
                            .clickable { onKindChange(k) }.padding(horizontal = 12.dp, vertical = 6.dp),
                    ) { Text(k.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) Pal.OnGreen else Pal.TextSec) }
                }
            }
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF111215)).padding(14.dp),
                contentAlignment = Alignment.Center,
            ) {
                if (preview != null) {
                    Image(
                        preview, "Widget preview", contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth(if (kind == WidgetKind.COMPACT) 0.6f else 1f).aspectRatio(w / h),
                    )
                } else Box(Modifier.fillMaxWidth().aspectRatio(w / h))
            }
        }

        // --- theme ---
        Group("Theme Style", "Glassmorphism") {
            ThemeStyle.entries.toList().chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { t ->
                        OptionCard(
                            selected = settings.theme == t, modifier = Modifier.weight(1f),
                            onClick = { SettingsStore.update { it.copy(theme = t) } },
                        ) {
                            Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(10.dp)).background(swatch(t)))
                            Text(t.label, color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                            Text(t.sub, color = Pal.TextSec, fontSize = 11.sp)
                        }
                    }
                    if (row.size == 1) Box(Modifier.weight(1f))
                }
            }
        }

        // --- opacity ---
        Group("Glass Opacity", "${(settings.opacity * 100).roundToInt()}%") {
            Slider(
                value = settings.opacity, onValueChange = { v -> SettingsStore.update { it.copy(opacity = v) } },
                valueRange = 0.3f..0.98f,
                colors = SliderDefaults.colors(thumbColor = Pal.GreenBright, activeTrackColor = Pal.Green, inactiveTrackColor = Color(0x22FFFFFF)),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TechText("Clear Glass (30%)", Pal.TextTer, 10); TechText("Opaque Slate (98%)", Pal.TextTer, 10)
            }
        }

        // --- typography ---
        Group("Lyric Typography", settings.font.label) {
            LyricFont.entries.toList().chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { f ->
                        val fam: FontFamily = when (f) {
                            LyricFont.SANS -> fonts.sans; LyricFont.SERIF -> fonts.serif
                            LyricFont.MONO -> fonts.mono; LyricFont.GROTESK -> fonts.tech
                        }
                        OptionCard(settings.font == f, Modifier.weight(1f), { SettingsStore.update { it.copy(font = f) } }) {
                            TechText(f.preview.uppercase(), Pal.TextTer, 10)
                            Text(f.label, style = TextStyle(fontFamily = fam, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Pal.Text), modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }

        // --- glow ---
        Group("Active Line Glow", settings.glow.label) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                GlowColor.entries.forEach { g ->
                    val sel = settings.glow == g
                    Column(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) Pal.CardHigh else Color.Transparent)
                            .clickable { SettingsStore.update { it.copy(glow = g) } }.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(g.argb)).then(if (sel) Modifier.border(2.dp, Color.White, CircleShape) else Modifier), contentAlignment = Alignment.Center) {
                            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        }
                        Text(g.label, color = Pal.TextSec, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }

        // --- elements ---
        Group("Widget Elements", "Visibility") {
            ToggleRow("Show Album Cover Art", "Mini square artwork thumbnail", settings.showArt) { v -> SettingsStore.update { it.copy(showArt = v) } }
            ToggleRow("Show Timestamp Scrubber", "Current track progress (Medium widget)", settings.showProgress) { v -> SettingsStore.update { it.copy(showProgress = v) } }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lyric Context Lines", color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Single phrase vs 3-line lookahead", color = Pal.TextSec, fontSize = 11.sp)
                }
                Segmented(listOf(1 to "1 Line", 3 to "3 Lines"), settings.contextLines, { v -> SettingsStore.update { it.copy(contextLines = v) } })
            }
        }

        // --- combos ---
        Group("Quick Aesthetic Combos", null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Combo("Nocturne Echo", Pal.GreenBright) { it.copy(theme = ThemeStyle.AMOLED, glow = GlowColor.GREEN, font = LyricFont.SANS, opacity = 0.95f) }
                Combo("Hyperpop Synth", Pal.PurpleSoft) { it.copy(theme = ThemeStyle.NEON, glow = GlowColor.LILAC, font = LyricFont.GROTESK, opacity = 0.92f) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Combo("Warm Vinyl", Color(0xFFFFB74D)) { it.copy(theme = ThemeStyle.VINYL, glow = GlowColor.AMBER, font = LyricFont.SERIF, opacity = 0.95f) }
                Combo("Album Bloom", Color(0xFF5EEAD4)) { it.copy(theme = ThemeStyle.ALBUM, glow = GlowColor.CYAN, font = LyricFont.SANS, opacity = 0.9f) }
            }
        }

        // --- apply ---
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(CircleShape).background(Pal.Green)
                .clickable {
                    val n = WidgetUpdater.activeCount(ctx)
                    scope.launch(Dispatchers.Default) { WidgetUpdater.updateAll(ctx) }
                    Toast.makeText(ctx, if (n == 0) "Saved. Add a widget from the Widgets tab." else "Applied to $n widget(s)", Toast.LENGTH_SHORT).show()
                }.padding(vertical = 15.dp),
            contentAlignment = Alignment.Center,
        ) { Text("APPLY TO ACTIVE WIDGETS", color = Pal.OnGreen, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 0.8.sp) }
        Text(
            "Changes save automatically and update your widgets live while Spotify is playing.",
            color = Pal.TextTer, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp),
        )
    }
}

@Composable
private fun Combo(label: String, dot: Color, apply: (WidgetSettings) -> WidgetSettings) {
    Row(
        Modifier.clip(CircleShape).background(Pal.CardHigh).clickable { SettingsStore.update(apply) }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
        Text(label, color = Pal.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))
    }
}

private fun swatch(t: ThemeStyle): Brush = when (t) {
    ThemeStyle.FROSTED -> Brush.verticalGradient(listOf(Color(0xFF3A3C48), Color(0xFF22242C)))
    ThemeStyle.AMOLED -> Brush.verticalGradient(listOf(Color.Black, Color(0xFF050505)))
    ThemeStyle.ALBUM -> Brush.linearGradient(listOf(Color(0xFF7B1FD1), Color(0xFF2A0E45)))
    ThemeStyle.VINYL -> Brush.verticalGradient(listOf(Color(0xFF3B2A1E), Color(0xFF281C14)))
    ThemeStyle.NEON -> Brush.linearGradient(listOf(Color(0xFF1A0833), Color(0xFF3B0F6B), Color(0xFF0E3B2A)))
}

@Composable
private fun Group(title: String, badge: String?, content: @Composable () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), radius = 20.dp) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Pal.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                if (badge != null) Chip(badge, Pal.GreenBright, Pal.Green.copy(alpha = 0.12f))
            }
            content()
        }
    }
}

@Composable
private fun OptionCard(selected: Boolean, modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) Pal.CardHigh else Color(0xFF16171B))
            .border(1.dp, if (selected) Pal.Green.copy(alpha = 0.6f) else Pal.Hairline, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(12.dp),
    ) { content() }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(sub, color = Pal.TextSec, fontSize = 11.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Pal.Green, checkedThumbColor = Pal.OnGreen, uncheckedTrackColor = Pal.CardHigh, uncheckedThumbColor = Pal.TextSec),
        )
    }
}
