package com.lyricdrop.app.ui

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun rememberTicker(periodMs: Long = 250L): State<Long> = produceState(SystemClock.elapsedRealtime()) {
    while (true) {
        value = SystemClock.elapsedRealtime()
        delay(periodMs)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 16.dp,
    background: Color = Pal.Card,
    borderColor: Color = Pal.Hairline,
    content: @Composable () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(radius))
            .background(background)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(radius)),
    ) { content() }
}

@Composable
fun Chip(text: String, color: Color = Pal.GreenBright, bg: Color = Color(0x0FFFFFFF), modifier: Modifier = Modifier) {
    val tech = LocalFonts.current.tech
    Box(
        modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, Pal.Hairline, CircleShape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(
            text, color = color, fontFamily = tech, fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp, letterSpacing = 0.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun TechText(text: String, color: Color = Pal.TextTer, size: Int = 11, modifier: Modifier = Modifier) {
    Text(text, color = color, fontFamily = LocalFonts.current.tech, fontSize = size.sp, fontWeight = FontWeight.Medium, modifier = modifier)
}

@Composable
fun AlbumArt(bitmap: Bitmap?, size: Dp, radius: Dp = 12.dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(radius)
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(), contentDescription = "Album art",
            contentScale = ContentScale.Crop, modifier = modifier.size(size).clip(shape),
        )
    } else {
        Box(
            modifier.size(size).clip(shape).background(Brush.linearGradient(listOf(Pal.Green, Pal.Purple))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(size * 0.5f))
        }
    }
}

@Composable
fun GradientProgress(progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(14.dp)) {
        val h = 5.dp.toPx()
        val y = (size.height - h) / 2f
        drawRoundRect(Color(0x1FFFFFFF), Offset(0f, y), Size(size.width, h), CornerRadius(h))
        val fill = size.width * progress.coerceIn(0f, 1f)
        if (fill > 0f) {
            drawRoundRect(
                Brush.horizontalGradient(listOf(Pal.Green, Pal.Purple), 0f, size.width),
                Offset(0f, y), Size(fill, h), CornerRadius(h),
            )
            drawCircle(Color.White, 6.dp.toPx(), Offset(fill.coerceIn(6.dp.toPx(), size.width - 6.dp.toPx()), size.height / 2f))
            drawCircle(Pal.Green, 6.dp.toPx(), Offset(fill.coerceIn(6.dp.toPx(), size.width - 6.dp.toPx()), size.height / 2f), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        }
    }
}

@Composable
fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(CircleShape).background(Color(0xFF111215)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEach { (value, label) ->
            val sel = value == selected
            Box(
                Modifier.clip(CircleShape)
                    .background(if (sel) Pal.Green else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = if (sel) Pal.OnGreen else Pal.TextSec,
                )
            }
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Pal.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun TopBar(status: String, ok: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0F3D22), Color(0xFF1B1B1F)))),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.MusicNote, null, tint = Pal.GreenBright) }
        Column(Modifier.padding(start = 12.dp)) {
            Text("LyricDrop", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "● $status",
                color = if (ok) Pal.GreenBright else Pal.TextSec,
                style = TextStyle(fontFamily = LocalFonts.current.tech, fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
