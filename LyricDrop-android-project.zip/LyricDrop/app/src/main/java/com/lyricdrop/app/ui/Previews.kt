package com.lyricdrop.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.lyricdrop.app.data.WidgetKind
import com.lyricdrop.app.data.WidgetSettings
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.widget.RenderInput
import com.lyricdrop.app.widget.WidgetRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Live data when Spotify is playing, otherwise a demo track so previews are never empty. */
@Composable
fun rememberLiveInput(): RenderInput {
    val np by PlayerHub.nowPlaying.collectAsState()
    val lyrics by PlayerHub.lyrics.collectAsState()
    val settings by SettingsStore.state.collectAsState()
    @Suppress("UNUSED_VARIABLE") val tick by rememberTicker(1000)
    return if (np == null) RenderInput.demo() else RenderInput.from(np, lyrics, settings.offsetMs)
}

/** Renders the real widget bitmap off the main thread - the preview is pixel-identical to the widget. */
@Composable
fun rememberWidgetPreview(
    kind: WidgetKind, settings: WidgetSettings, input: RenderInput, widthDp: Float, heightDp: Float,
): ImageBitmap? {
    val ctx = LocalContext.current
    val density = ctx.resources.displayMetrics.density
    val state = produceState<ImageBitmap?>(null, kind, settings, input, widthDp, heightDp) {
        value = withContext(Dispatchers.Default) {
            WidgetRenderer.render(ctx, kind, settings, input, widthDp, heightDp, density).asImageBitmap()
        }
    }
    return state.value
}
