package com.lyricdrop.app.widget

import android.graphics.Bitmap
import com.lyricdrop.app.data.LrcParser
import com.lyricdrop.app.data.LyricsState
import com.lyricdrop.app.data.NowPlaying

/** Everything the renderer needs, already resolved to plain strings/numbers. */
data class RenderInput(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val prev: String?,
    val current: String,
    val next: String?,
    val next2: String?,
    val posMs: Long,
    val durMs: Long,
    val playing: Boolean,
    val isDemo: Boolean = false,
    val label: String = "LIVE SYNC",
) {
    val progress: Float get() = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f

    companion object {
        fun demo() = RenderInput(
            title = "Birds of a Feather",
            artist = "Billie Eilish",
            art = null,
            prev = "I want you to stay",
            current = "'Til I rot away, dead and buried",
            next = "'Til I'm in the casket you carry",
            next2 = "If you go, I'm goin' too, uh",
            posMs = 134_000,
            durMs = 210_000,
            playing = true,
            isDemo = true,
            label = "PREVIEW",
        )

        fun idle() = RenderInput(
            title = "LyricDrop",
            artist = "Waiting for Spotify",
            art = null,
            prev = null,
            current = "Play a song on Spotify to see its lyrics here",
            next = null,
            next2 = null,
            posMs = 0, durMs = 0, playing = false,
            label = "IDLE",
        )

        fun from(np: NowPlaying?, lyrics: LyricsState, offsetMs: Long): RenderInput {
            if (np == null) return idle()
            val pos = np.positionNow()
            fun base(prev: String?, cur: String, n1: String?, n2: String?, label: String = "LIVE SYNC") = RenderInput(
                np.title, np.artist, np.art, prev, cur, n1, n2, pos, np.durationMs, np.isPlaying, false, label,
            )
            return when (lyrics) {
                is LyricsState.Synced -> {
                    val lines = lyrics.lines
                    val idx = LrcParser.indexAt(lines, pos + offsetMs)
                    fun t(i: Int): String? = lines.getOrNull(i)?.text?.ifBlank { "♪" }
                    if (idx < 0) base(null, "♪", t(0), t(1))
                    else base(t(idx - 1), t(idx) ?: "♪", t(idx + 1), t(idx + 2))
                }
                LyricsState.Loading -> base(null, "Fetching lyrics…", null, null, "LOADING")
                is LyricsState.Plain -> base(null, "Lyrics found, but not time-synced", null, null, "NO SYNC")
                LyricsState.Instrumental -> base(null, "♪ Instrumental ♪", null, null, "INSTRUMENTAL")
                LyricsState.NotFound -> base(null, "No lyrics found for this track", null, null, "NOT FOUND")
                is LyricsState.Error -> base(null, "Couldn't reach the lyrics service", null, null, "OFFLINE")
                LyricsState.Idle -> base(null, "…", null, null, "IDLE")
            }
        }
    }
}
