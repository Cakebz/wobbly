package com.lyricdrop.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Saved lyric snippets, persisted as JSON in SharedPreferences. */
object SnippetStore {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow<List<Snippet>>(emptyList())
    val state: StateFlow<List<Snippet>> = _state.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences("snippets", Context.MODE_PRIVATE)
        val raw = prefs.getString("list", "[]") ?: "[]"
        _state.value = runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Snippet(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    artist = o.getString("artist"),
                    text = o.getString("text"),
                    timeMs = o.getLong("timeMs"),
                    createdAt = o.getLong("createdAt"),
                    liked = o.optBoolean("liked", false),
                )
            }
        }.getOrDefault(emptyList())
    }

    fun add(title: String, artist: String, text: String, timeMs: Long) {
        if (text.isBlank()) return
        val exists = _state.value.any { it.text == text && it.title == title }
        if (exists) return
        val now = System.currentTimeMillis()
        persist(listOf(Snippet(now, title, artist, text, timeMs, now)) + _state.value)
    }

    fun toggleLike(id: Long) =
        persist(_state.value.map { if (it.id == id) it.copy(liked = !it.liked) else it })

    fun remove(id: Long) = persist(_state.value.filterNot { it.id == id })

    private fun persist(list: List<Snippet>) {
        _state.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("artist", it.artist)
                    .put("text", it.text).put("timeMs", it.timeMs)
                    .put("createdAt", it.createdAt).put("liked", it.liked),
            )
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
