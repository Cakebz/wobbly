package com.lyricdrop.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.lyricdrop.app.MainActivity
import com.lyricdrop.app.R
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.WidgetKind
import com.lyricdrop.app.service.PlayerHub

object WidgetUpdater {

    fun providerFor(kind: WidgetKind): Class<out AppWidgetProvider> = when (kind) {
        WidgetKind.COMPACT -> CompactWidget::class.java
        WidgetKind.MEDIUM -> MediumWidget::class.java
        WidgetKind.PILL -> PillWidget::class.java
        WidgetKind.LARGE -> LargeWidget::class.java
    }

    fun idsFor(context: Context, kind: WidgetKind): IntArray =
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, providerFor(kind)))

    fun activeCount(context: Context): Int = WidgetKind.entries.sumOf { idsFor(context, it).size }

    fun defaultSizeDp(kind: WidgetKind): Pair<Float, Float> = when (kind) {
        WidgetKind.COMPACT -> 160f to 160f
        WidgetKind.MEDIUM -> 320f to 160f
        WidgetKind.PILL -> 320f to 56f
        WidgetKind.LARGE -> 320f to 320f
    }

    fun updateAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        for (kind in WidgetKind.entries) {
            for (id in idsFor(context, kind)) update(context, mgr, kind, id)
        }
    }

    fun update(context: Context, mgr: AppWidgetManager, kind: WidgetKind, id: Int) {
        val ctx = context.applicationContext
        val opts: Bundle = mgr.getAppWidgetOptions(id)
        val (defW, defH) = defaultSizeDp(kind)
        // Portrait: width = min width, height = max height. Good enough for both orientations.
        val w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).takeIf { it > 0 }?.toFloat() ?: defW
        val h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).takeIf { it > 0 }?.toFloat() ?: defH

        val settings = SettingsStore.state.value
        val input = RenderInput.from(PlayerHub.nowPlaying.value, PlayerHub.lyrics.value, settings.offsetMs)
        val bmp = WidgetRenderer.render(ctx, kind, settings, input, w, h, ctx.resources.displayMetrics.density)

        val views = RemoteViews(ctx.packageName, R.layout.widget_root)
        views.setImageViewBitmap(R.id.widget_image, bmp)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        views.setOnClickPendingIntent(R.id.widget_frame, open)
        mgr.updateAppWidget(id, views)
    }
}

abstract class BaseLyricWidget(private val kind: WidgetKind) : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { WidgetUpdater.update(context, mgr, kind, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle) {
        WidgetUpdater.update(context, mgr, kind, id)
    }
}

class CompactWidget : BaseLyricWidget(WidgetKind.COMPACT)
class MediumWidget : BaseLyricWidget(WidgetKind.MEDIUM)
class PillWidget : BaseLyricWidget(WidgetKind.PILL)
class LargeWidget : BaseLyricWidget(WidgetKind.LARGE)
