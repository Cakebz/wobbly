package com.lyricdrop.app.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.lyricdrop.app.data.LyricFont
import com.lyricdrop.app.data.ThemeStyle
import com.lyricdrop.app.data.WidgetKind
import com.lyricdrop.app.data.WidgetSettings
import com.lyricdrop.app.data.formatTime
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Draws every widget (and the in-app live previews) onto a Bitmap with Canvas. Doing it this way
 * gives full control over fonts, glow, gradients and rounded glass panels - things RemoteViews can't do.
 */
object WidgetRenderer {

    private const val PURPLE = 0xFF9D4EDD.toInt()

    fun render(
        context: Context,
        kind: WidgetKind,
        s: WidgetSettings,
        input: RenderInput,
        widthDp: Float,
        heightDp: Float,
        density: Float,
    ): Bitmap {
        var d = density
        var w = (widthDp * d).toInt().coerceAtLeast(40)
        var h = (heightDp * d).toInt().coerceAtLeast(40)
        // RemoteViews has a bitmap memory ceiling; keep well under it.
        val maxPx = 900_000f
        if (w * h > maxPx) {
            val k = sqrt(maxPx / (w * h))
            d *= k; w = (w * k).toInt(); h = (h * k).toInt()
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = Renderer(context, c, w.toFloat(), h.toFloat(), d, s, input)
        r.draw(kind)
        return bmp
    }

    /** 9:16 share card for a saved lyric snippet. */
    fun renderQuoteCard(
        context: Context,
        s: WidgetSettings,
        quote: String,
        title: String,
        artist: String,
        w: Int = 1080,
        h: Int = 1920,
    ): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val input = RenderInput(title, artist, null, null, quote, null, null, 0, 0, false)
        // 360dp-wide virtual canvas: 1080px => density 3, 540px => 1.5, so layouts match at any size.
        Renderer(context, c, w.toFloat(), h.toFloat(), w / 360f, s, input).drawQuoteCard()
        return bmp
    }

    private class Renderer(
        val ctx: Context,
        val c: Canvas,
        val w: Float,
        val h: Float,
        val d: Float,
        val s: WidgetSettings,
        val input: RenderInput,
    ) {
        val glow = s.glow.argb
        val cream = s.theme == ThemeStyle.VINYL
        val white = if (cream) 0xFFFFF3E0.toInt() else Color.WHITE
        val sec = withAlpha(white, 0.60f)
        val ter = withAlpha(white, 0.36f)
        val radius = 22f * d
        val full = RectF(0f, 0f, w, h)

        fun dp(v: Float) = v * d

        // ---------- shared helpers ----------

        fun withAlpha(color: Int, a: Float) = Color.argb((a * 255).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

        fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt(),
        )

        fun avgColor(bmp: Bitmap?): Int? = bmp?.let {
            runCatching { Bitmap.createScaledBitmap(it, 1, 1, true).getPixel(0, 0) }.getOrNull()
        }

        fun paint(color: Int, tf: Typeface, sizeDp: Float) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; typeface = tf; textSize = dp(sizeDp)
        }

        fun layout(text: String, p: TextPaint, width: Int, maxLines: Int = Int.MAX_VALUE, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout =
            StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(1))
                .setAlignment(align)
                .setIncludePad(false)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setLineSpacing(0f, 1.08f)
                .build()

        /** Largest font size (within [minDp, maxDp]) at which the text fits in the box. */
        fun fit(text: String, p: TextPaint, widthPx: Float, heightPx: Float, maxDp: Float, minDp: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout {
            var size = dp(maxDp)
            val minPx = dp(minDp)
            while (true) {
                p.textSize = size
                val l = layout(text, p, widthPx.toInt(), align = align)
                if (l.height <= heightPx || size <= minPx) {
                    if (l.height <= heightPx) return l
                    val lineH = (l.height / l.lineCount.toFloat()).coerceAtLeast(1f)
                    val lines = max(1, (heightPx / lineH).toInt())
                    return layout(text, p, widthPx.toInt(), lines, align)
                }
                size -= dp(1f)
            }
        }

        fun drawLayout(l: StaticLayout, x: Float, y: Float) {
            c.save(); c.translate(x, y); l.draw(c); c.restore()
        }

        fun drawText(text: String, p: TextPaint, x: Float, baseline: Float, maxWidth: Float, align: Paint.Align = Paint.Align.LEFT) {
            val t = TextUtils.ellipsize(text, p, maxWidth, TextUtils.TruncateAt.END).toString()
            p.textAlign = align
            c.drawText(t, x, baseline, p)
            p.textAlign = Paint.Align.LEFT
        }

        fun glowPaint(p: TextPaint, radiusDp: Float = 10f, alpha: Float = 0.55f): TextPaint {
            p.setShadowLayer(dp(radiusDp), 0f, 0f, withAlpha(glow, alpha)); return p
        }

        fun drawArt(rect: RectF, rad: Float) {
            val art = input.art
            val path = Path().apply { addRoundRect(rect, rad, rad, Path.Direction.CW) }
            if (art == null) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, withAlpha(glow, 0.9f), PURPLE, Shader.TileMode.CLAMP)
                c.drawPath(path, p)
                val np = paint(Color.WHITE, Typeface.DEFAULT_BOLD, rect.height() / d * 0.5f)
                np.textAlign = Paint.Align.CENTER
                c.drawText("♪", rect.centerX(), rect.centerY() - (np.ascent() + np.descent()) / 2f, np)
                return
            }
            val shader = BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val scale = max(rect.width() / art.width, rect.height() / art.height)
            val m = Matrix()
            m.setScale(scale, scale)
            m.postTranslate(rect.left + (rect.width() - art.width * scale) / 2f, rect.top + (rect.height() - art.height * scale) / 2f)
            shader.setLocalMatrix(m)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader }
            c.drawPath(path, p)
        }

        fun drawProgress(left: Float, right: Float, y: Float) {
            val th = dp(4f)
            val track = RectF(left, y - th / 2, right, y + th / 2)
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(Color.WHITE, 0.14f) }
            c.drawRoundRect(track, th, th, tp)
            val fillRight = left + (right - left) * input.progress
            if (fillRight > left + th) {
                val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(left, 0f, right, 0f, glow, PURPLE, Shader.TileMode.CLAMP)
                }
                c.drawRoundRect(RectF(left, track.top, fillRight, track.bottom), th, th, fp)
            }
        }

        // ---------- backgrounds ----------

        fun drawBackground(withArtBleed: Boolean = false) {
            val a = s.opacity.coerceIn(0.3f, 1f)
            val path = Path().apply { addRoundRect(full, radius, radius, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG)
            when (s.theme) {
                ThemeStyle.FROSTED -> {
                    fill.color = Color.argb((a * 255).toInt(), 26, 28, 38); c.drawRect(full, fill)
                    fill.shader = LinearGradient(0f, 0f, 0f, h, withAlpha(Color.WHITE, 0.10f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawRect(full, fill)
                    fill.shader = RadialGradient(w * 0.15f, h * 1.05f, max(w, h) * 0.75f, withAlpha(glow, 0.20f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawRect(full, fill)
                }
                ThemeStyle.AMOLED -> {
                    fill.color = Color.argb((a * 255).toInt(), 0, 0, 0); c.drawRect(full, fill)
                }
                ThemeStyle.ALBUM -> {
                    val avg = avgColor(input.art) ?: blend(glow, Color.BLACK, 0.6f)
                    val top = blend(avg, Color.BLACK, 0.45f)
                    val bottom = blend(avg, Color.BLACK, 0.85f)
                    fill.shader = LinearGradient(0f, 0f, w, h, withAlpha(top, a), withAlpha(bottom, a), Shader.TileMode.CLAMP)
                    c.drawRect(full, fill)
                }
                ThemeStyle.VINYL -> {
                    fill.color = Color.argb((a * 255).toInt(), 40, 28, 20); c.drawRect(full, fill)
                    val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE; strokeWidth = dp(1f); color = withAlpha(0xFFFFE0B2.toInt(), 0.08f)
                    }
                    val cx = w * 0.92f; val cy = h * 0.5f
                    var rr = dp(18f)
                    while (rr < max(w, h) * 1.1f) { c.drawCircle(cx, cy, rr, ring); rr += dp(9f) }
                    fill.shader = null
                    fill.color = withAlpha(0xFFB2682E.toInt(), 0.35f)
                    c.drawCircle(cx, cy, dp(16f), fill)
                }
                ThemeStyle.NEON -> {
                    fill.color = Color.argb((a * 255).toInt(), 11, 6, 22); c.drawRect(full, fill)
                    fill.shader = RadialGradient(w, 0f, max(w, h) * 0.9f, withAlpha(PURPLE, 0.45f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawRect(full, fill)
                    fill.shader = RadialGradient(0f, h, max(w, h) * 0.8f, withAlpha(glow, 0.30f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawRect(full, fill)
                }
            }
            c.restore()
            // hairline border
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = if (s.theme == ThemeStyle.NEON) dp(1.6f) else dp(1f)
                color = if (s.theme == ThemeStyle.NEON) withAlpha(glow, 0.75f) else withAlpha(Color.WHITE, 0.14f)
            }
            val inset = border.strokeWidth / 2
            c.drawRoundRect(RectF(inset, inset, w - inset, h - inset), radius, radius, border)
        }

        // ---------- widget layouts ----------

        fun draw(kind: WidgetKind) {
            when (kind) {
                WidgetKind.COMPACT -> compact()
                WidgetKind.MEDIUM -> medium()
                WidgetKind.PILL -> pill()
                WidgetKind.LARGE -> large()
            }
        }

        fun header(x: Float, y: Float, artDp: Float, titleSp: Float, artistSp: Float, maxW: Float): Float {
            var tx = x
            val artPx = dp(artDp)
            if (s.showArt) {
                drawArt(RectF(x, y, x + artPx, y + artPx), dp(8f))
                tx = x + artPx + dp(10f)
            }
            val tp = paint(white, Fonts.ui(ctx, 700), titleSp)
            val ap = paint(sec, Fonts.ui(ctx, 500), artistSp)
            val textH = tp.fontSpacing + ap.fontSpacing
            val top = y + (artPx - textH) / 2f
            drawText(input.title, tp, tx, top - tp.ascent(), x + maxW - tx)
            drawText(input.artist, ap, tx, top + tp.fontSpacing - ap.ascent(), x + maxW - tx)
            return artPx
        }

        fun compact() {
            drawBackground()
            val pad = dp(14f)
            val inner = w - pad * 2
            val artH = header(pad, pad, 30f, 12.5f, 10.5f, inner)
            // footer
            val tp = paint(ter, Fonts.tech(ctx, 500), 10f)
            val footerBase = h - pad - tp.descent()
            drawText(formatTime(input.posMs), tp, pad, footerBase, inner / 2)
            val lp = paint(glow, Fonts.tech(ctx, 600), 9f).apply { letterSpacing = 0.06f }
            val label = "● ${input.label}"
            drawText(label, lp, w - pad, footerBase, inner / 2, Paint.Align.RIGHT)
            // lyric
            val top = pad + artH + dp(8f)
            val bottom = footerBase + tp.ascent() - dp(8f)
            val lyricP = glowPaint(paint(white, Fonts.lyric(ctx, s.font, 800), 18f), 8f, 0.5f)
            val l = fit(input.current, lyricP, inner, bottom - top, 19f, 10f)
            drawLayout(l, pad, top + (bottom - top - l.height) / 2f)
        }

        fun medium() {
            drawBackground()
            val pad = dp(16f)
            val inner = w - pad * 2
            val artH = header(pad, pad, 38f, 14.5f, 11.5f, inner)
            val showProg = s.showProgress
            val footerH = if (showProg) dp(26f) else 0f
            val top = pad + artH + dp(8f)
            val bottom = h - pad - footerH

            if (s.contextLines >= 3 && (bottom - top) > dp(60f)) {
                val dimP = paint(withAlpha(white, 0.40f), Fonts.lyric(ctx, s.font, 600), 12.5f)
                val boxH = bottom - top
                val sideH = dimP.fontSpacing
                input.prev?.let {
                    drawText(it, dimP, pad, top - dimP.ascent(), inner)
                }
                input.next?.let {
                    drawText(it, dimP, pad, bottom - dimP.descent(), inner)
                }
                val curTop = top + sideH + dp(4f)
                val curBottom = bottom - sideH - dp(4f)
                val lyricP = glowPaint(paint(glow, Fonts.lyric(ctx, s.font, 800), 18f), 10f, 0.5f)
                val l = fit(input.current, lyricP, inner, curBottom - curTop, 20f, 11f)
                drawLayout(l, pad, curTop + (curBottom - curTop - l.height) / 2f)
            } else {
                val lyricP = glowPaint(paint(glow, Fonts.lyric(ctx, s.font, 800), 22f), 12f, 0.5f)
                val l = fit(input.current, lyricP, inner, bottom - top, 26f, 11f)
                drawLayout(l, pad, top + (bottom - top - l.height) / 2f)
            }

            if (showProg) {
                val y = h - pad - dp(14f)
                val tp = paint(ter, Fonts.tech(ctx, 500), 10f)
                val baseline = h - pad - tp.descent()
                drawProgress(pad, w - pad, y - dp(2f))
                drawText(formatTime(input.posMs), tp, pad, baseline, inner / 3)
                drawText(formatTime(input.durMs), tp, w - pad, baseline, inner / 3, Paint.Align.RIGHT)
                val lp = paint(glow, Fonts.tech(ctx, 600), 9f).apply { letterSpacing = 0.06f }
                drawText(input.label, lp, w / 2f, baseline, inner / 3, Paint.Align.CENTER)
            }
        }

        fun pill() {
            val a = s.opacity.coerceIn(0.3f, 1f)
            val pillR = h / 2f
            val path = Path().apply { addRoundRect(full, pillR, pillR, Path.Direction.CW) }
            c.save(); c.clipPath(path)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG)
            fill.color = when (s.theme) {
                ThemeStyle.AMOLED -> Color.argb((a * 255).toInt(), 0, 0, 0)
                ThemeStyle.VINYL -> Color.argb((a * 255).toInt(), 40, 28, 20)
                ThemeStyle.NEON -> Color.argb((a * 255).toInt(), 11, 6, 22)
                ThemeStyle.ALBUM -> withAlpha(blend(avgColor(input.art) ?: glow, Color.BLACK, 0.7f), a)
                ThemeStyle.FROSTED -> Color.argb((a * 255).toInt(), 26, 28, 38)
            }
            c.drawRect(full, fill)
            c.restore()
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = dp(1f)
                color = if (s.theme == ThemeStyle.NEON) withAlpha(glow, 0.75f) else withAlpha(Color.WHITE, 0.14f)
            }
            c.drawRoundRect(RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f), pillR, pillR, border)

            val pad = h * 0.18f
            var x = pad
            if (s.showArt) {
                val sz = h - pad * 2
                drawArt(RectF(x, pad, x + sz, pad + sz), sz / 2f)
                x += sz + dp(10f)
            }
            val lp = glowPaint(paint(white, Fonts.lyric(ctx, s.font, 700), (h / d * 0.30f).coerceIn(11f, 16f)), 6f, 0.5f)
            val dot = dp(6f)
            val textRight = w - pad - dot * 2 - dp(8f)
            val baseline = h / 2f - (lp.ascent() + lp.descent()) / 2f
            drawText(input.current, lp, x, baseline, textRight - x)
            val dp2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (input.playing) glow else ter }
            c.drawCircle(w - pad - dot, h / 2f, dot, dp2)
        }

        fun large() {
            val path = Path().apply { addRoundRect(full, radius, radius, Path.Direction.CW) }
            // base
            drawBackground()
            c.save(); c.clipPath(path)
            // album art bleed across the whole poster
            val artBmp = input.art
            if (artBmp != null && s.showArt) {
                val art: Bitmap = artBmp
                val sh = BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = max(w / art.width, h / art.height)
                val m = Matrix(); m.setScale(sc, sc)
                m.postTranslate((w - art.width * sc) / 2f, (h - art.height * sc) / 2f)
                sh.setLocalMatrix(m)
                c.drawRect(full, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = sh; alpha = (s.opacity * 255).toInt().coerceIn(120, 255) })
            }
            val scrim = Paint().apply {
                shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(withAlpha(Color.BLACK, 0.15f), withAlpha(Color.BLACK, 0.55f), withAlpha(Color.BLACK, 0.92f)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            }
            c.drawRect(full, scrim)
            c.restore()

            val pad = dp(18f)
            val inner = w - pad * 2
            // top chip
            val chip = paint(glow, Fonts.tech(ctx, 600), 10f).apply { letterSpacing = 0.06f }
            val chipText = "● ${input.label}"
            val cw = chip.measureText(chipText) + dp(16f)
            val chipRect = RectF(pad, pad, pad + cw, pad + dp(22f))
            c.drawRoundRect(chipRect, dp(11f), dp(11f), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(Color.BLACK, 0.45f) })
            c.drawText(chipText, chipRect.left + dp(8f), chipRect.centerY() - (chip.ascent() + chip.descent()) / 2f, chip)

            // footer
            val tp = paint(sec, Fonts.tech(ctx, 500), 11f)
            val footBase = h - pad - tp.descent()
            drawText("${input.artist}", tp, pad, footBase, inner * 0.62f)
            drawText("${formatTime(input.posMs)} / ${formatTime(input.durMs)}", tp, w - pad, footBase, inner * 0.38f, Paint.Align.RIGHT)

            // title label
            val lab = paint(glow, Fonts.ui(ctx, 800), 11f).apply { letterSpacing = 0.08f }
            val labBase = footBase + tp.ascent() - dp(14f)
            drawText(input.title.uppercase(), lab, pad, labBase, inner)

            // quote
            val quoteBottom = labBase + lab.ascent() - dp(8f)
            val quoteTop = h * 0.30f
            val prevH = if (s.contextLines >= 3 && input.prev != null) dp(18f) else 0f
            val qp = glowPaint(paint(white, Fonts.lyric(ctx, s.font, 800), 28f), 12f, 0.35f)
            val text = "“${input.current}”"
            val l = fit(text, qp, inner, quoteBottom - quoteTop - prevH, 32f, 12f)
            val qy = quoteBottom - l.height
            drawLayout(l, pad, qy)
            if (prevH > 0f) {
                val pp = paint(withAlpha(white, 0.55f), Fonts.lyric(ctx, s.font, 500), 12f)
                drawText(input.prev ?: "", pp, pad, qy - dp(8f) - pp.descent(), inner)
            }
        }

        // ---------- share card ----------

        fun drawQuoteCard() {
            val bg = Paint()
            bg.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF0A0B0E.toInt(), blend(glow, Color.BLACK, 0.78f), 0xFF0A0B0E.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(full, bg)
            val g = Paint().apply { shader = RadialGradient(w * 0.2f, h * 0.25f, w * 0.9f, withAlpha(PURPLE, 0.35f), Color.TRANSPARENT, Shader.TileMode.CLAMP) }
            c.drawRect(full, g)

            val pad = w * 0.09f
            val inner = w - pad * 2
            val mark = paint(withAlpha(glow, 0.9f), Fonts.lyric(ctx, LyricFont.SERIF, 800), 90f)
            c.drawText("“", pad, h * 0.24f, mark)

            val qp = glowPaint(paint(white, Fonts.lyric(ctx, s.font, 800), 40f), 14f, 0.35f)
            val l = fit(input.current, qp, inner, h * 0.38f, 46f, 20f)
            val top = h * 0.5f - l.height / 2f
            drawLayout(l, pad, top)

            val ap = paint(white, Fonts.ui(ctx, 700), 15f)
            drawText(input.artist, ap, pad, top + l.height + dp(48f), inner)
            val tp = paint(sec, Fonts.ui(ctx, 500), 13f)
            drawText(input.title, tp, pad, top + l.height + dp(48f) + ap.fontSpacing, inner)

            val brand = paint(glow, Fonts.tech(ctx, 700), 12f).apply { letterSpacing = 0.12f }
            drawText("LYRICDROP", brand, pad, h - h * 0.06f, inner)
        }
    }
}
