package com.lyricdrop.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.lyricdrop.app.data.SettingsStore
import com.lyricdrop.app.data.Snippet
import com.lyricdrop.app.data.SnippetStore
import com.lyricdrop.app.data.WidgetSettings
import com.lyricdrop.app.data.formatTime
import com.lyricdrop.app.service.PlayerHub
import com.lyricdrop.app.widget.WidgetRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

fun shareCardImage(ctx: Context, s: WidgetSettings, sn: Snippet) {
    val bmp = WidgetRenderer.renderQuoteCard(ctx, s, sn.text, sn.title, sn.artist)
    val dir = File(ctx.cacheDir, "cards").apply { mkdirs() }
    val file = File(dir, "lyricdrop_${sn.id}.png")
    FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, "Share lyric card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun SavedScreen(mode: Int, onModeChange: (Int) -> Unit, selectedId: Long, onSelect: (Long) -> Unit) {
    val snippets by SnippetStore.state.collectAsState()
    val np by PlayerHub.nowPlaying.collectAsState()

    Column(Modifier.fillMaxSize()) {
        TopBar(if (np != null) "Spotify Connected • ${np!!.artist}" else "Saved lyrics", np != null)
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth()
                .clip(CircleShape).background(Color(0xFF111215)).padding(5.dp),
        ) {
            Tab("Saved Snippets (${snippets.size})", mode == 0, Modifier.weight(1f)) { onModeChange(0) }
            Tab("Card Studio", mode == 1, Modifier.weight(1f)) { onModeChange(1) }
        }
        if (mode == 0) SnippetList(snippets, onRemix = { onSelect(it); onModeChange(1) })
        else CardStudio(snippets, selectedId, onSelect)
    }
}

@Composable
private fun Tab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CircleShape).background(if (selected) Pal.GreenBright else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Pal.OnGreen else Pal.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
    }
}

@Composable
private fun SnippetList(snippets: List<Snippet>, onRemix: (Long) -> Unit) {
    val ctx = LocalContext.current
    if (snippets.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Pal.TextTer, modifier = Modifier.size(40.dp))
            Text("No snippets yet", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 12.dp))
            Text(
                "While a song is playing, tap the bookmark button next to the lyrics to save the current line here.",
                color = Pal.TextSec, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }
        return
    }
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(snippets, key = { it.id }) { sn ->
            GlassCard(Modifier.fillMaxWidth(), radius = 20.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AlbumArt(null, 44.dp, 10.dp)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(sn.title, color = Pal.Text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(sn.artist, color = Pal.TextSec, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Chip(formatTime(sn.timeMs), Pal.TextSec)
                        Box(Modifier.size(40.dp).clickable { SnippetStore.toggleLike(sn.id) }, contentAlignment = Alignment.Center) {
                            Icon(if (sn.liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Like", tint = Pal.GreenBright)
                        }
                    }
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.CardHigh).padding(14.dp)) {
                        Text("“${sn.text}”", color = Pal.Text, fontSize = 18.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            Modifier.weight(1f).clip(CircleShape).background(Color(0xFF1E3A29)).clickable { onRemix(sn.id) }.padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Brush, null, tint = Pal.GreenBright, modifier = Modifier.size(18.dp))
                            Text("Remix Card", color = Pal.GreenBright, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 6.dp))
                        }
                        SmallIcon(Icons.Rounded.ContentCopy, "Copy") {
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("lyric", "“${sn.text}” — ${sn.artist}, ${sn.title}"))
                            Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                        }
                        SmallIcon(Icons.Rounded.Delete, "Delete") { SnippetStore.remove(sn.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Pal.CardHigh).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = Color.White)
    }
}

@Composable
private fun CardStudio(snippets: List<Snippet>, selectedId: Long, onSelect: (Long) -> Unit) {
    val ctx = LocalContext.current
    if (snippets.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(32.dp)) {
            Text("Save a lyric first", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text("Card Studio turns any saved lyric into a 9:16 story image you can share.", color = Pal.TextSec, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        }
        return
    }
    val settings by SettingsStore.state.collectAsState()
    val current = snippets.firstOrNull { it.id == selectedId } ?: snippets.first()
    val preview by produceState<ImageBitmap?>(null, current, settings) {
        value = withContext(Dispatchers.Default) {
            WidgetRenderer.renderQuoteCard(ctx, settings, current.text, current.title, current.artist, 540, 960).asImageBitmap()
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxWidth(0.62f).aspectRatio(9f / 16f).clip(RoundedCornerShape(20.dp)).background(Color(0xFF111215))) {
                preview?.let { Image(it, "Card preview", modifier = Modifier.fillMaxSize()) }
            }
        }
        Text("Pick a lyric", color = Pal.Text, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        snippets.take(8).forEach { sn ->
            val sel = sn.id == current.id
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (sel) Pal.CardHigh else Color(0xFF16171B))
                    .clickable { onSelect(sn.id) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("“${sn.text}”", color = Pal.Text, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text("${sn.artist} • ${sn.title}", color = Pal.TextTer, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (sel) Chip("Selected", Pal.GreenBright)
            }
        }
        Row(
            Modifier.fillMaxWidth().clip(CircleShape).background(Pal.Green).clickable { shareCardImage(ctx, settings, current) }.padding(vertical = 15.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Share, null, tint = Pal.OnGreen, modifier = Modifier.size(18.dp))
            Text("SHARE AS IMAGE", color = Pal.OnGreen, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Text("The card uses your Studio font and glow colour.", color = Pal.TextTer, fontSize = 11.sp)
    }
}
